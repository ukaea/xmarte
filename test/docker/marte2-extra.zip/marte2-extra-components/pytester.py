#!/usr/bin/env python3
import socket
import struct
import time

def main():
    # Ask user for frequency (Hz)
    freq = float(input("Enter frequency (Hz): ").strip())
    period = 1.0 / freq

    # Create UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    addr = ("127.0.0.1", 40442)

    counter = 0
    print(f"Sending uint32 values to {addr} at {freq} Hz... (Ctrl+C to stop)")

    try:
        while True:
        #if True:
            # Pack counter as uint32 (little endian)
            data = struct.pack("<I", counter)

            # Send the packet
            sock.sendto(data, addr)

            # Debug print
            print(f"Sent: {counter}")

            # Increment counter (wrap around 32-bit unsigned)
            counter = (counter + 1) & 0xFFFFFFFF

            # Sleep until next tick
            time.sleep(period)
    except KeyboardInterrupt:
        print("\nStopped.")

if __name__ == "__main__":
    main()
