import socket
import struct
import time
import sys

# Destination
UDP_IP = "0.0.0.0"
UDP_PORT = 40442

# Payload values
trigger = 0       # uint32
const_value = 2      # uint32

# Pack data as two unsigned 32-bit integers (little-endian)
payload = struct.pack('<II', trigger, const_value)

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    print(f"Sending UDP packets to {UDP_IP}:{UDP_PORT} (Ctrl+C to stop)...")

    try:
        while True:
            sock.sendto(payload, (UDP_IP, UDP_PORT))
            time.sleep(0.01)  # send at 100Hz; adjust or remove if not needed
    except KeyboardInterrupt:
        print("\nStopped by user.")
        sock.close()
        sys.exit(0)

if __name__ == "__main__":
    main()
