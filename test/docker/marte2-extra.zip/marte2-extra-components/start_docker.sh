#!/bin/bash


docker run -it -e DISPLAY=$DISPLAY -v /mnt/c/users/tq7638/documents/github/marte2-extra-components-mastu:/marte -v /mnt/c/users/tq7638/documents/github/mastu/differ:/root/differ -v /tmp/.X11-unix:/tmp/.X11-unix --network host git.ccfe.ac.uk:4567/marte21/xmarte:matlab_marte_rocky /bin/bash
